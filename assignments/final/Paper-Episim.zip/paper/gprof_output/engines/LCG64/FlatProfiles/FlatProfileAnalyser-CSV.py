import sys
import os
import fnmatch
from datetime import datetime
from collections import OrderedDict

def num(s):
	try:
		return int(s)
	except ValueError:
		return float(s)

def isNumeric(s):
	try:
		float(s)
		return True
	except ValueError:
		return False

def GetValues(line):
	values = []
	for i in range(0,6):
		result = line.split(' ', 1)
		if( len(result) == 2 and isNumeric(result[0]) ):
			values.append(num(result[0]))
			line = result[1].lstrip()
		else:
			for j in range(0, 6-len(values)):
				values.append(0)
	key = line
	return (key, values)

def ReadFlatProfiles():
	maps = []
	files = [f for f in os.listdir('.') if (os.path.isfile(f) and fnmatch.fnmatch(f, 'run*flat_profile*.txt'))]
	for f in files:
		contents = open(f, "r")
		map = OrderedDict()
		for line in contents.read().split('\n')[5:-1]:
			key, values = GetValues(line.lstrip())
			if( map.has_key(key) ):
				for i in range(0, len(map[key])):
					map[key][i] += values[i]
			else:
				map[key] = values
		maps.append(map)
	return maps
		

def GetLargest(maps):
	largest = {}
	for map in maps:
		if( len(map) > len(largest) ):
			largest = map
	return largest	


def CalculateAvg(maps):
	copy = GetLargest(maps).copy()
	for key in copy:
		for i in range(0, len(copy[key])):
			temp = 0
			count = 1
			for map in maps:
				if( map.has_key(key) ):
					temp += map[key][i]
					count += 1
			copy[key][i] = (temp / count)
	return copy
				


if __name__ == '__main__':
	pmaps = ReadFlatProfiles()
	avg = CalculateAvg(pmaps)
	file = open("avg_flat_profiles.tsv","w")
	file.write("Flat profile (average):\n\n")
	file.write("Each sample counts as 0.01 seconds.\n")
	file.write("%time\tcumulative seconds\tself seconds\tcalls\tself s/call\ttotal s/call\tname\n")
	for key in avg:
		temp = ""
		for val in avg[key]:
			temp += str(val) if isinstance(val, int) else  ("%0.2f" % val)
			temp += "\t"
		temp += key + "\n"
		file.write(temp)



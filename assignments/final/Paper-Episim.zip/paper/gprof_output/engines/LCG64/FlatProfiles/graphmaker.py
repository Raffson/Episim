from pandas import DataFrame, read_csv
import numpy as np
import pandas as pd
import os
from decimal import Decimal
import plotly.plotly as py
import plotly.graph_objs as go

print("starting graphs maker")
dirname=os.getcwd()
dirs=dirname.split('/')
outputname=''
for val in dirs[6:]:
	outputname+=val
	outputname+='_'
outputname+='output'
print(outputname)
#read data from csv
Location = r'./avg_flat_profiles.tsv'
df = pd.read_csv(Location, names=['%time','cumulative seconds','self seconds','calls','self s/call','total s/call','name'], sep='\t')
df = pd.DataFrame(data=df)
#print(df['name']) # Access the differennt columns
#print(df[3:23]) # Only rows 3-22
#print(df) # Start processing from line 3 (0,1,2 are not data)
###
### SKIPPED cumulative seconds
###
#df = df.sort_values(by=['total s/call'], ascending=False)
selected = df[3:23]
Y = selected['total s/call']
vals=[]
for value in Y:
	vals.append(value)
vals.append(0.01)
n = selected['name']
names=[]
for name in n:
	names.append(name)
names.append("other")
df2 = pd.DataFrame(data=vals, index=names)
print(df2)
"""
trace = go.Pie(labels=names, values=vals)
data=[trace]
layout=go.Layout(legend=dict(x=0.3,y=-0.5))
fig=go.Figure(data=data, layout=layout)
py.iplot(fig, filename=outputname)"""


import sys
import os
import fnmatch
from datetime import datetime

def num(s):
	try:
		return int(s)
	except ValueError:
		return float(s)


def ToSeconds(t):
	total = float(t[2])
	total += (float(t[1])*60)
	total += (float(t[0])*3600)
	total += (float(t[3])/1000)
	total += (float(t[4])/1000000)
	return total
				

def GetAvgRT(dir):
	files = [f for f in os.listdir(dir) if (os.path.isfile(dir+f) and fnmatch.fnmatch(f, 'run*stride_output*.txt'))]
	avgPopgen = 0
	avgRunner = 0
	for f in files:
		contents = open(dir+f, "r")
		contents = contents.read()
		avgPopgen += num(contents.split('=')[1].split('\n')[0].lstrip())
		avgRunner += ToSeconds(contents.split('=')[1].split('\n')[-3].split(':')[3:])
	avgPopgen /= len(files)
	avgRunner /= len(files)
	return [avgPopgen, avgRunner]


if __name__ == '__main__':
	dirs = [d for d in os.listdir('.') if os.path.isdir(d)]
	avgs = []
	for d in sorted(dirs, key=len):
		if( os.path.isdir(d+"/StrideOutput") ):
			result = GetAvgRT(d+"/StrideOutput/")
			avgs.append([d]+result)

	file = open("avg_run-times.txt","w")
	file.write("Average run-times in seconds:\n")
	file.write("param\tpopgen\t\tsimrunner\n")
	totalPopgen = 0
	totalRunner = 0
	for avg in avgs:
		totalPopgen += avg[1]
		totalRunner += avg[2]
		param = avg[0] if len(avg[0]) < 8 else avg[0][:7]
		line = param + "\t" + ("%0.6f" % avg[1]) + "\t" + ("%0.6f" % avg[2]) + "\n"
		file.write(line)
	
	file.write("total\t" + ("%0.6f\t" % (totalPopgen/len(avgs))) + ("%0.6f\n" % (totalRunner/len(avgs))))


import matplotlib.pyplot as plt
import sys
import matplotlib.mlab as mlab
import numpy as np
from pylab import savefig
from scipy import stats
import os
import math


# noinspection PyShadowingNames
def file_to_list(file):
    """
    :param file: a config file with seeds and death counts
    :return: a list of value's from the dat file
    """
    seed_lst = []
    res_list = []
    with open(file, "r") as f:
        for line in f:
            try:
                line_list = line.split()
                seed_lst.append(int(line_list[0]))
                res_list.append(int(line_list[1]))

            except ValueError:
                pass

    res_list.sort()
    return seed_lst, res_list


def calc_lower_bound(data):
    return data[0]


def calc_higher_bound(data):
    return data[-1]


def plot_histogram(lst, path, gap_s, nm):

    if not os.path.exists("{0}/histograms".format(path)):
        os.makedirs("{0}/histograms".format(path))

    print("Plotting Histogram...")
    sigma = np.std(lst)
    mean = np.mean(lst)

    n, bins, patches = plt.hist(lst, gap_s, normed=1, facecolor='green', edgecolor="black")
    y = mlab.normpdf(bins, mean, sigma)
    plt.plot(bins, y, 'r--', linewidth=1)

    plt.ylabel('Probability')
    plt.xlabel('Infected count')

    plt.grid(True)
    plt.title("Histogram of infected count:\n mean={0},"
              " stdev={1}".format(mean, sigma))


    path_name = "{0}/histograms/{1}-histogram.png".format(path, nm)
    savefig(path_name)
    print("Histogram written to {0}".format(path_name))
    plt.close()


def plot_boxplot(data, path,nm):

    if not os.path.exists("{0}/boxplots".format(path)):
        os.makedirs("{0}/boxplots".format(path))

    print("Plotting Boxplot...")
    plt.boxplot(data)
    plt.ylabel("Infected count")
    plt.title("Boxplot of infected count")
    path_name = "{0}/boxplots/{1}-boxplot.png".format(path, nm)
    savefig(path_name)
    print("Boxplot written to {0}".format(path_name))
    plt.close()


def plot_qqplot(data, path,nm):

    if not os.path.exists("{0}/qqplots".format(path)):
        os.makedirs("{0}/qqplots".format(path))

    print("Plotting QQ-plot...")
    stats.probplot(data, plot=plt)
    path_name = "{0}/qqplots/{1}-qqplot.png".format(path, nm)
    savefig(path_name)
    print("QQ-plot written to {0}".format(path_name))
    plt.close()


def plot_scatterplot(x, y, path,nm):

    if not os.path.exists("{0}/scatterplots".format(path)):
        os.makedirs("{0}/scatterplots".format(path))

    print("Plotting Scatterplot...")
    plt.scatter(x, y)
    plt.axhline(y= np.mean(y), color='r', linestyle='-')
    plt.xlabel("Seeds")
    plt.ylabel("Infected count")
    plt.title("Scatter plot")
    path_name = "{0}/scatterplots/{1}-scatterplot.png".format(path, nm)
    savefig(path_name)
    print("Scatter-plot written to {0}".format(path_name))
    plt.close()


def main(file, gap_s):
    seed_lst, lst = file_to_list(file)
    file = file.split("/")
    nm = file.pop(-1)
    nm = nm[:len(nm) - 4]
    file = "/".join(file)

    print("Calculating data from {0}....".format(file))

    mean = np.mean(lst)
    std = np.std(lst,ddof = 1)
    lower_bound = calc_lower_bound(lst)
    lp =  1 - lower_bound/mean
    higher_bound = calc_higher_bound(lst)
    hp = higher_bound/mean - 1
    plb = stats.norm.cdf(lower_bound, loc=mean, scale=std)
    phb = 1 - stats.norm.cdf(higher_bound, loc=mean, scale=std)
    pin = 1 - plb - phb
    ceilp = math.ceil(max(hp, lp)*100)/100
    ceilplb = mean*(1-ceilp)
    ceilphb = mean*(1+ceilp)
    cplb = stats.norm.cdf(ceilplb, loc=mean, scale=std)
    cphb = 1 - stats.norm.cdf(ceilphb, loc=mean, scale=std)
    cpin = 1 - cplb - cphb
    threePPlb = stats.norm.cdf(mean*0.97, loc=mean, scale=std)
    threePPhb = 1 - stats.norm.cdf(mean*1.03, loc=mean, scale=std)
    shapiro_stat, p_value = stats.shapiro(lst)
    #r = stats.norm.interval(0.99, loc=mean, scale=std )
    r = stats.t.interval(0.999999999,len(lst)-1, loc=mean, scale=stats.sem(lst) )

    margin_lower = (mean - lower_bound) / mean
    margin_higher = (higher_bound - mean) / mean
    margin = max(margin_lower, margin_higher)

    conf_name = file.split("/")[-1]
    if not os.path.exists("{0}/summaries".format(file)):
        os.makedirs("{0}/summaries".format(file))

    f_write = "{0}/summaries/{1}-stats.txt".format(file, nm)
    print("Data calculating done. Writing to /{0}".format(f_write))

    with open(f_write, 'w') as writer:
        writer.writelines([
            "Mean:                    {0}\n".format(mean),
            "Standard deviation:      {0}\n".format(std),
            "Lower bound:             {0}\n".format(lower_bound),
            "Upper bound:             {0}\n\n".format(higher_bound),
            "LB % from mean:          {0}%\n".format(lp*100),
            "UB % from mean:          {0}%\n".format(hp*100),
            "P(X < LowerBound):       {0}%\n".format(plb*100),
            "P(X > UpperBound):       {0}%\n".format(phb*100),
            "P(LB < X < UB):          {0}%\n\n".format(pin*100),
            "Ceil(Max(LB%, UB%)):\t\t\t{0}%\n".format(ceilp*100),
            "{0}% around mean:\t\t\t({1}, {2})\n".format(ceilp*100, ceilplb, ceilphb),
            "P(X < {0}):\t\t\t{1}%\n".format(ceilplb, cplb*100),
            "P(X > {0}):\t\t\t{1}%\n".format(ceilphb, cphb*100),
            "P({0} < X < {1}):\t{2}%\n\n".format(ceilplb, ceilphb, cpin*100),
            "3% around mean:\t\t\t\t({0}, {1})\n".format(mean*0.97, mean*1.03),
            "P(X < {0}):\t\t\t{1}%\n".format(mean*0.97, threePPlb*100),
            "P(X > {0}):\t\t\t{1}%\n".format(mean*1.03, threePPhb*100),
            "P({0} < X < {1}):\t{2}%\n\n".format(mean*0.97, mean*1.03, (1 - threePPlb - threePPhb)*100),
            "Shapiro-wilk test-stat:  {0}\n".format(shapiro_stat),
            "Shapiro-Wilk p-value:    {0}\n".format(p_value),
            "99% confidence interval: {0}\n".format(r)])#,
            #"Batchrun.cpp margin:     {0}%\n".format(margin)
        #])

    plot_histogram(lst, file, gap_s, nm)
    plot_boxplot(lst, file, nm)
    plot_qqplot(lst, file, nm)
    plot_scatterplot(seed_lst, lst, file, nm)


def recurse_dirs(file_path):
    for sub_file in os.listdir(file_path):
        if sub_file.endswith(".dat"):
            true_file = "{0}/{1}".format(file_path, sub_file)
            main(true_file, gap_size)

        elif os.path.isdir("{0}/{1}".format(file_path,sub_file)):
            recurse_dirs("{0}/{1}".format(file_path,sub_file))


if __name__ == '__main__':

    gap_size = 50
    filename = None

    if len(sys.argv) == 3:
        gap = sys.argv[2]

    if len(sys.argv) == 2:
        filename = sys.argv[1]

    if os.path.isfile(filename):
        main(filename, gap_size)

    elif os.path.isdir(filename):
        recurse_dirs(filename)
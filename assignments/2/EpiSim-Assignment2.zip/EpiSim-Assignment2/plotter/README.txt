README:

Run het script met 1ste argument pad naar een seedresult file

Optionele 2de argument dat de 'bucket grootte' van het histogram bepaald.
(hoeveel infected counts we samen nemen)

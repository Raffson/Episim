import matplotlib.pyplot as plt
import sys
import matplotlib.mlab as mlab
import numpy as np
from pylab import savefig


# noinspection PyShadowingNames
def file_to_list(file):
    """

    :params:
        filename: path to config file with seeds and infected count
	bucket-size (optional):  relates to candle size of histogram
    :return:
    """
    res_list = []
    with open(file, "r") as f:
        for line in f:
            try:
                line_list = line.split()
                res_list.append(int(line_list[1]))

            except ValueError:
                pass

    res_list.sort()
    return res_list


# noinspection PyShadowingNames
def calc_lower_bound(lst):
    return np.mean(lst) - np.mean(lst) / 10


# noinspection PyShadowingNames
def calc_higher_bound(lst):
    return np.mean(lst) + np.mean(lst) / 10


# noinspection PyShadowingNames
def plot(lst):
    sigma = np.std(lst)
    mean = np.mean(lst)

    n, bins, patches = plt.hist(lst, 50, normed=1, facecolor='green', edgecolor="black")
    y = mlab.normpdf(bins, mean, sigma)
    plt.plot(bins, y, 'r--', linewidth=1)

    plt.ylabel('Probability')
    plt.xlabel('Infected count')

    plt.grid(True)
    # noinspection PyTypeChecker,PyTypeChecker
    plt.title("Histogram of infected count:\n mean={0},"
              " stdev={1}".format(int(round(mean)), int(round(sigma))))

    savefig("histogram.png")


if __name__ == '__main__':

    gap = 50
    file = None

    if len(sys.argv) == 3:
        gap = sys.argv[2]

    if len(sys.argv) == 2:
        file = sys.argv[1]

    lst = file_to_list(file)
    # noinspection PyTypeChecker
    print("Mean: " + str(int(round(np.mean(lst)))))
    # noinspection PyTypeChecker
    print("Standard deviation: " + str(int(round(np.std(lst)))))
    # noinspection PyTypeChecker,PyTypeChecker
    print("Bounds: [" + str(int(round(calc_lower_bound(lst)))) + ","
          + str(int(round(calc_higher_bound(lst)))) + "]")

    plot(lst)
